package com.adisr.trafico


import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import com.adisr.trafico.databinding.ActivityHomeBinding
import kotlinx.android.synthetic.main.content_home.*
import kotlinx.android.synthetic.main.nav_header_home.*

enum class ProviderType{
    BASIC
}


class HomeActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityHomeBinding

    private val  rotateOpen: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.rotate_open_anim) }
    private val  rotateClose: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.rotate_close_anim) }
    private val  fromBottom: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.from_bottom_anim) }
    private val  toBottom: Animation by lazy { AnimationUtils.loadAnimation( this, R.anim.to_bottom_anim) }

    private var clicked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarHome.toolbar)

        binding.appBarHome.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
            val bundle=intent.extras
            bundle?.getString("email")
            val email=bundle?.getString("email")
            val provider=bundle?.getString("provider")
            setup(email?:"")



        }
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_home)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)



        config_buttom.setOnClickListener {
            onAddButtomclicked()
        }

        camera_buttom.setOnClickListener {
            Toast.makeText(this, "Botón de cámara presionado", Toast.LENGTH_SHORT).show()
        }

        noti_buttom.setOnClickListener {
            Toast.makeText(this, "Botón de notificación presionado", Toast.LENGTH_SHORT).show()
        }

    }



    private fun onAddButtomclicked() {
        setVisibility(clicked)
        setAnimation(clicked)
        clicked = !clicked
    }

    private fun setVisibility(clicked: Boolean) {
        if (!clicked){
            camera_buttom.visibility = View.VISIBLE
            noti_buttom.visibility = View.VISIBLE
        }else{
            camera_buttom.visibility = View.INVISIBLE
            noti_buttom.visibility = View.INVISIBLE
        }

    }

    private fun setClickeable(clicked: Boolean){
    if (!clicked){
        camera_buttom.isClickable = false
        noti_buttom.isClickable = false
    }else{
        camera_buttom.isClickable = true
        noti_buttom.isClickable = true
    }
    }


    private fun setAnimation(clicked: Boolean) {
        if (!clicked){
            camera_buttom.startAnimation(fromBottom)
            noti_buttom.startAnimation(fromBottom)
            config_buttom.startAnimation(rotateOpen)
        }else{
            camera_buttom.startAnimation(toBottom)
            noti_buttom.startAnimation(toBottom)
            config_buttom.startAnimation(rotateClose)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.home, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_home)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
    private fun setup(email:String){
        txtemail.text=email
    }
}